/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Ali
 */
import java.sql.*;
import javax.swing.*;
import java.sql.Connection;
public class javaconnect {
    
  public  Connection conn = null;
    
    public  static Connection connecrDB() {
    
        try{
        Class.forName("org.sqlite.JDBC");
        
        Connection conn =  DriverManager.getConnection("jdbc:sqlite:C:\\Users\\Ali\\Documents\\NetBeansProjects\\Project123\\project123.sqlite");
        JOptionPane.showMessageDialog(null ,"Established connection");
      //  return conn;
        }
        catch(Exception e){
        JOptionPane.showMessageDialog(null , e);
      //  return null;
        }
      return null;
    
    }

    private static class connection {

        public connection() {
                    }
    }

   
}
